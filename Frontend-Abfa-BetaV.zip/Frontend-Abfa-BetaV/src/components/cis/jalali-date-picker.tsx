import { useState } from "react";
import { CalendarDays, X } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { gToJ, jMonthTitle, shiftJMonth, startOfDay, toJalali, toJalaliLong, weekdayName } from "@/lib/jalali";
import { JalaliCalendar } from "./jalali-calendar";

export { JalaliCalendar, type JRange, type JMonth } from "./jalali-calendar";

/** Visible Jalali month with prev/next moves (calendar page). */
export function useJalaliCursor(initial?: Date) {
  const j = gToJ(initial ?? new Date());
  const [c, setC] = useState({ y: j.jy, m: j.jm });
  const move = (d: number) => setC(({ y, m }) => shiftJMonth(y, m, d));
  return { ...c, set: setC, move, title: jMonthTitle(c.y, c.m) };
}

type PickerProps = {
  value?: Date | undefined;
  onChange?: (d: Date) => void;
  /** When given, an × clears the date (optional fields and filters). */
  onClear?: () => void;
  placeholder?: string;
  /** Applied to the outer box (width / flex). */
  className?: string;
  id?: string;
  /** "sm" = compact control for table filters and toolbars. */
  size?: "md" | "sm";
  min?: Date | undefined;
  max?: Date | undefined;
  invalid?: boolean;
  "aria-describedby"?: string | undefined;
};

/** Solar Hijri date field: trigger styled like every other form control, calendar popover with «امروز» and «پاک کردن». */
export function JalaliDatePicker({ value, onChange, onClear, placeholder = "انتخاب تاریخ", className, id, size = "md", min, max, invalid, ...aria }: PickerProps) {
  const [open, setOpen] = useState(false);
  const sm = size === "sm";
  const pick = (d: Date) => { onChange?.(d); setOpen(false); };
  const today = startOfDay(new Date());
  const todayOff = (min && today < startOfDay(min)) || (max && today > startOfDay(max));
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <div className={cn("relative", sm ? "min-w-28" : "w-full", className)}>
        <PopoverTrigger asChild>
          <button id={id} type="button" aria-invalid={invalid || undefined} aria-describedby={aria["aria-describedby"]}
            aria-label={value ? `${placeholder}: ${toJalaliLong(value)}` : placeholder}
            className={cn("field-control flex w-full items-center text-start font-normal",
              sm ? "h-8 min-h-8 gap-1.5 rounded-md ps-1.5 pe-2 text-xs" : "h-11 gap-2.5 ps-2 pe-3 text-sm",
              value && onClear && (sm ? "pe-6" : "pe-9"))}>
            <span aria-hidden className={cn("grid shrink-0 place-items-center rounded-md transition-colors", sm ? "size-5" : "size-7", value ? "bg-primary-soft text-primary" : "bg-muted text-muted-foreground")}>
              <CalendarDays className={sm ? "size-3" : "size-3.5"} />
            </span>
            {value ? (
              <span className="flex min-w-0 items-baseline gap-1.5">
                <span className="font-bold text-foreground">{toJalali(value)}</span>
                {!sm && <span className="truncate text-xs text-muted-foreground">{weekdayName(value)}</span>}
              </span>
            ) : <span className="truncate text-muted-foreground">{placeholder}</span>}
          </button>
        </PopoverTrigger>
        {value && onClear && (
          <button type="button" onClick={onClear} aria-label="پاک کردن تاریخ" title="پاک کردن تاریخ"
            className={cn("absolute top-1/2 grid -translate-y-1/2 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-destructive-soft hover:text-destructive", sm ? "end-1.5 size-4" : "end-2.5 size-6")}>
            <X className={sm ? "size-3" : "size-3.5"} />
          </button>
        )}
      </div>
      <PopoverContent align="start" className="w-auto overflow-hidden rounded-2xl p-0">
        <div className="p-3"><JalaliCalendar selected={value} onSelect={pick} min={min} max={max} autoFocus /></div>
        <div className="flex items-center gap-1.5 border-t border-border/80 bg-muted/50 px-3 py-2">
          <span className="min-w-0 flex-1 truncate text-xs text-muted-foreground">{value ? toJalaliLong(value) : "تاریخی انتخاب نشده"}</span>
          {value && onClear && <Button type="button" size="sm" variant="ghost" className="h-7 px-2 text-xs text-muted-foreground hover:bg-destructive-soft hover:text-destructive" onClick={() => { onClear(); setOpen(false); }}>پاک کردن</Button>}
          <Button type="button" size="sm" variant="soft" className="h-7 px-2.5 text-xs" disabled={Boolean(todayOff)} onClick={() => pick(today)}>امروز</Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

/** «مشاهده در تاریخ» – for temporal (as-of) queries */
export function AsOfPicker({ value, onChange }: { value: Date; onChange: (d: Date) => void }) {
  return (
    <div className="flex items-center gap-2 rounded-lg border border-border bg-card py-1 pe-1 ps-2.5 text-sm shadow-card">
      <span className="whitespace-nowrap text-xs font-semibold text-muted-foreground">نمایش در تاریخ</span>
      <JalaliDatePicker value={value} onChange={onChange} size="sm" className="w-36" placeholder="تاریخ" />
    </div>
  );
}

